//  Calendar JS

const monthNames = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];

let today = new Date();
let currentMonth = today.getMonth();
let currentYear = today.getFullYear();

function generateCalendar(year, month) {
  const firstDay = new Date(year, month, 1).getDay();
  const lastDate = new Date(year, month + 1, 0).getDate();
  let date = 1;
  let table = "";

  for (let i = 0; i < 6; i++) {
    let row = "<tr>";
    for (let j = 0; j < 7; j++) {
      if (i === 0 && j < firstDay) {
        row += `<td class="inactive"></td>`;
      } else if (date > lastDate) {
        row += `<td class="inactive"></td>`;
      } else {
        let classes = "";
        // Today date mark
        if (
          date === today.getDate() &&
          month === today.getMonth() &&
          year === today.getFullYear()
        ) {
          classes = "today";
        }
        row += `<td class="${classes}" onclick="selectDate(this)">${date}</td>`;
        date++;
      }
    }
    row += "</tr>";
    table += row;
  }

  document.getElementById("calendar-body").innerHTML = table;
  document.getElementById("monthYear").innerText = `${monthNames[month]} ${year}`;
}

function selectDate(cell) {
  document.querySelectorAll("#calendar-body td").forEach(td => td.classList.remove("selected"));
  if (!cell.classList.contains("inactive")) {
    cell.classList.add("selected");
  }
}

document.getElementById("prevBtn").addEventListener("click", () => {
  currentMonth--;
  if (currentMonth < 0) {
    currentMonth = 11;
    currentYear--;
  }
  generateCalendar(currentYear, currentMonth);
});

document.getElementById("nextBtn").addEventListener("click", () => {
  currentMonth++;
  if (currentMonth > 11) {
    currentMonth = 0;
    currentYear++;
  }
  generateCalendar(currentYear, currentMonth);
});

generateCalendar(currentYear, currentMonth);


// foooter JS



function toBanglaNumber(num) {
  const banglaDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  return num.toString().replace(/[0-9]/g, d => banglaDigits[d]);
}

function updateDateTime() {
  const now = new Date();

  const year = toBanglaNumber(now.getFullYear());
  const month = toBanglaNumber(String(now.getMonth() + 1).padStart(2, '0'));
  const day = toBanglaNumber(String(now.getDate()).padStart(2, '0'));

  const hours = toBanglaNumber(String(now.getHours()).padStart(2, '0'));
  const minutes = toBanglaNumber(String(now.getMinutes()).padStart(2, '0'));
  const seconds = toBanglaNumber(String(now.getSeconds()).padStart(2, '0'));

  const formattedDate = `${day}-${month}-${year}`;
  const formattedTime = `${hours}:${minutes}:${seconds}`;

  document.getElementById("last-update").textContent = formattedDate + " " + formattedTime;
}

// প্রথমবার চালু হবে
updateDateTime();
// প্রতি সেকেন্ডে নতুন সময় বসবে
setInterval(updateDateTime, 1000);


